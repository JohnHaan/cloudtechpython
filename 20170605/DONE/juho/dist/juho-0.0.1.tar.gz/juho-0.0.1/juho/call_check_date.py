import sys

sys.path.append('/projects/cloudtechpython/20170605')

from juho import check_date

check_date.main()